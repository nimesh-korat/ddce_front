import React, { useState } from "react";
import Sidebar from "../../common/sidebar";
import Header from "../../common/header/Header";
import { Link } from "react-router-dom";
import { getSubjectWiseAnalysis, getPracticeAccuracy } from "../../apis/apis";
import { useQuery } from "@tanstack/react-query";
import Preloader from "../../utils/preloader/Preloader";
import Footer from "../../common/footer";

function MasteryMatrix() {
  const [isSidebarActive, setIsSidebarActive] = useState(false);
  const [mode, setMode] = useState("merged"); // "merged" | "exam" | "practice"

  // Merged / practice / exam accuracy (new unified API)
  const { data: practiceData, isFetching: practiceFetching } = useQuery({
    queryKey: ["practiceAccuracy", mode],
    queryFn: () => getPracticeAccuracy(mode),
    refetchOnWindowFocus: false,
  });

  // Legacy exam-only query (kept for fallback if practiceData unavailable)
  const {
    data: examData,
    error,
    isFetching: examFetching,
  } = useQuery({
    queryKey: ["accuracyMatrixData"],
    queryFn: getSubjectWiseAnalysis,
    refetchOnWindowFocus: false,
    enabled: false, // only used as fallback
  });

  // Use practiceData when available, else fall back to examData
  const data = practiceData || examData;
  const isFetching = practiceFetching || examFetching;

  const toggleSidebar = () => {
    setIsSidebarActive((prevState) => !prevState);
  };

  const closeSidebar = () => {
    setIsSidebarActive(false);
  };

  if (error) {
    return <p>Error: {error.message}</p>;
  }

  return (
    <>
      <Sidebar isActive={isSidebarActive} closeSidebar={closeSidebar} />
      <div className="dashboard-main-wrapper">
        <Header toggleSidebar={toggleSidebar} />
        <div className="dashboard-body">
          <div className="breadcrumb-with-buttons mb-24 flex-between flex-wrap gap-8">
            <div className="breadcrumb mb-0">
              <ul className="flex-align gap-4">
                <li>
                  <Link
                    to={"/"}
                    className="text-gray-200 fw-normal text-15 hover-text-main-600"
                  >
                    Home
                  </Link>
                </li>
                <li>
                  <span className="text-gray-500 fw-normal d-flex">
                    <i className="ph ph-caret-right" />
                  </span>
                </li>
                <li>
                  <span className="text-main-600 fw-normal text-15">
                    Accuracy Matrix
                  </span>
                </li>
              </ul>
            </div>
            {/* Mode toggle */}
            {/* <div className="flex-align gap-4 bg-gray-50 p-4 rounded-pill">
              {[
                { key: "merged", label: "All", icon: "ph-funnel" },
                { key: "exam", label: "Exam Only", icon: "ph-exam" },
                { key: "practice", label: "Practice Only", icon: "ph-barbell" },
              ].map((m) => (
                <button
                  key={m.key}
                  className={`btn rounded-pill py-6 px-16 text-13 fw-medium flex-align gap-6 ${
                    mode === m.key ? "btn-main" : " text-gray-600"
                  }`}
                  onClick={() => setMode(m.key)}
                >
                  <i className={`ph ${m.icon}`} />
                  {m.label}
                </button>
              ))}
            </div> */}
          </div>
          <div className="container-fluid dashboard-content">
            {isFetching ? (
              <Preloader />
            ) : (
              <>
                <div className="row text-center mb-4 mt-4">
                  <div className="col-12">
                    <div className="card p-4 rounded shadow">
                      <div className="row g-3">
                        <div className="col-6 col-md-4 col-lg-2 mb-8">
                          <div className="mastery-stat-box">
                            <p className="mastery-stat-number text-primary">
                              {data?.OverallAnalytics?.TotalQuestionsAsked || 0}
                            </p>
                            <p className="mastery-stat-text">Asked</p>
                          </div>
                        </div>
                        <div className="col-6 col-md-4 col-lg-2 mb-8">
                          <div className="mastery-stat-box">
                            <p className="mastery-stat-number text-info">
                              {data?.OverallAnalytics?.TotalAttempted || 0}
                            </p>
                            <p className="mastery-stat-text">Attempted</p>
                          </div>
                        </div>
                        <div className="col-6 col-md-4 col-lg-2 mb-8">
                          <div className="mastery-stat-box">
                            <p className="mastery-stat-number text-success">
                              {data?.OverallAnalytics?.TotalCorrect || 0}
                            </p>
                            <p className="mastery-stat-text">Correct</p>
                          </div>
                        </div>
                        <div className="col-6 col-md-4 col-lg-2 mb-8">
                          <div className="mastery-stat-box">
                            <p className="mastery-stat-number text-danger">
                              {data?.OverallAnalytics?.TotalIncorrect || 0}
                            </p>
                            <p className="mastery-stat-text">Incorrect</p>
                          </div>
                        </div>
                        <div className="col-6 col-md-4 col-lg-2 mb-8">
                          <div className="mastery-stat-box">
                            <p className="mastery-stat-number text-warning">
                              {data?.OverallAnalytics?.TotalSkipped || 0}
                            </p>
                            <p className="mastery-stat-text">Skipped</p>
                          </div>
                        </div>
                        <div className="col-6 col-md-4 col-lg-2 mb-8">
                          <div className="mastery-stat-box">
                            <p className="mastery-stat-number text-success">
                              {data?.OverallAnalytics?.Accuracy || 0}%
                            </p>
                            <p className="mastery-stat-text">Accuracy</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="row mt-12 g-3">
                  {data?.OverallAnalytics?.TotalQuestionsAsked === 0 ? (
                    <div>
                      <div className="col-12 d-flex justify-content-center">
                        <img
                          src={"../assets/images/error/no_data_found.webp"}
                          style={{ width: "250px", height: "250px" }}
                          alt="No Data"
                        />
                      </div>
                      <h3 className="text-center">No Data Found For You</h3>
                    </div>
                  ) : (
                    data?.SubjectWiseAnalytics.map((subject, index) => {
                      if (subject.TotalAttempted === "0") {
                        return null;
                      }
                      let backgroundImage;
                      if (subject.Accuracy >= 90) {
                        backgroundImage =
                          "url(https://example.com/high-accuracy-background.jpg)";
                      } else if (subject.Accuracy >= 70) {
                        backgroundImage =
                          "url(https://example.com/medium-accuracy-background.jpg)";
                      } else if (subject.Accuracy >= 50) {
                        backgroundImage =
                          "url(https://example.com/low-accuracy-background.jpg)";
                      } else {
                        //eslint-disable-next-line
                        backgroundImage =
                          "url(https://example.com/very-low-accuracy-background.jpg)";
                      }

                      return (
                        <div className="col-md-6" key={index}>
                          <div
                            className="card shadow rounded"
                            style={{
                              backgroundImage:
                                "url(https://t3.ftcdn.net/jpg/04/12/82/16/360_F_412821610_95RpjzPXCE2LiWGVShIUCGJSktkJQh6P.jpg)",
                              backgroundSize: "cover",
                              backgroundColor: "rgba(255, 255, 255, 0.45)",
                              backgroundPosition: "center",
                              backgroundBlendMode: "overlay",
                            }}
                          >
                            <div className="card-body">
                              {/* <div className="d-flex justify-content-between align-items-center mb-3"> */}
                              {/* <img
                                src="../assets/images/icons/gold_trophy.png"
                                alt="Placeholder"
                                className="trophy-icon unselectable"
                              /> */}

                              {/* </div> */}
                              <div className="row mastery-subject-name">
                                <div className="col-7">
                                  <p className="font-weight-bold">
                                    {subject.Subject}
                                  </p>
                                </div>
                                <div className="col-5">
                                  <h1 className="mastery-percentage text-sm-end ">
                                    {subject.Accuracy}%
                                  </h1>
                                </div>
                              </div>
                              <div>
                                <div className="row text-center justify-content-between g-3">
                                  <div className="col-6 col-md-4 col-lg-2">
                                    <div className="mastery-stat-box">
                                      <p className="mastery-stat-number text-primary">
                                        {subject.TotalQuestionsAsked}
                                      </p>
                                      <p className="mastery-stat-text fw-bold">
                                        Asked
                                      </p>
                                    </div>
                                  </div>
                                  <div className="col-6 col-md-4 col-lg-2">
                                    <div className="mastery-stat-box">
                                      <p className="mastery-stat-number text-info">
                                        {subject.TotalAttempted}
                                      </p>
                                      <p className="mastery-stat-text fw-bold">
                                        Attempted
                                      </p>
                                    </div>
                                  </div>
                                  <div className="col-6 col-md-4 col-lg-2">
                                    <div className="mastery-stat-box">
                                      <p className="mastery-stat-number text-success">
                                        {subject.TotalCorrect}
                                      </p>
                                      <p className="mastery-stat-text fw-bold">
                                        Correct
                                      </p>
                                    </div>
                                  </div>
                                  <div className="col-6 col-md-4 col-lg-2">
                                    <div className="mastery-stat-box">
                                      <p className="mastery-stat-number text-danger">
                                        {subject.TotalIncorrect}
                                      </p>
                                      <p className="mastery-stat-text fw-bold">
                                        Incorrect
                                      </p>
                                    </div>
                                  </div>
                                  <div className="col-6 col-md-4 col-lg-2">
                                    <div className="mastery-stat-box">
                                      <p className="mastery-stat-number text-warning">
                                        {subject.TotalSkipped}
                                      </p>
                                      <p className="mastery-stat-text fw-bold">
                                        Skipped
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </>
            )}
          </div>
        </div>
        <Footer />
      </div>
    </>
  );
}

export default MasteryMatrix;
