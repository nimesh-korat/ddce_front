// import "react-toastify/dist/ReactToastify.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./modules/home_three";
// import Students from "./modules/students";
import SignIn from "./modules/signin";
// import Signup from "./modules/signup";
import ForgetPassword from "./modules/forget_password";
import ResetPassword from "./modules/reset_password";
import { ToastContainer } from "react-toastify";
import PrivateRoute from "./utils/PrivateRoutes";
import ProtectedRoute from "./utils/ProtectedRoutes";
import AccessGuard from "./utils/AccessGuard";
import BatchAccess from "./admin/BatchAccess";
import StudentAnswers from "./admin/StudentAnswers";
import Error404 from "./errorPages/Error404";
import TestTopicListing from "./modules/testTopicListing";
import AdminLogin from "./admin/login";
import AddQuestion from "./admin/AddQuestions";
import AdminRoutes from "./utils/AdminRoutes";
import ShowQuestions from "./admin/ShowQuestions";
import CreateTest from "./admin/CreateTest";
import ShowTests from "./admin/ShowTest";
import QuizResultsTab from "./admin/QuizResults";
import AddQuizQuestions from "./admin/AddQuizQuestion";
import Exam from "./modules/exams";
import GiveExam from "./modules/give_exam";
import ExamResult from "./modules/exam_result";
import Profile from "./modules/profile";
import Weightage from "./modules/weightage";
import Syllabus from "./modules/syllabus";
import QuestionVerification from "./admin/QuestionVerification";
import Analytics from "./modules/analytics";
import StudentQuizDetails from "./modules/exams/components/StudentQuizDetails";
import MasteryMatrix from "./modules/accuracy_matrix";
import ViewQuizQuestions from "./admin/ViewQuizQuestion";
// import Pricing from "./modules/pricing";
import Doubts from "./modules/doubt";
// import Schedule from "./modules/schedule";
import AssignBatchToTest from "./admin/AssignBatchToTest";
import AddSession from "./admin/AddSessions";
import ShowSession from "./admin/ShowSession";
import AssignSessionToBatch from "./admin/AssignSessionToBatch";
import Solutions from "./modules/solutions";
import ViewGivenExamData from "./admin/ViewGivenExamData";
import StudentWiseExamData from "./admin/StudentWiseExamData";
import CollgePredication from "./modules/college_predication";
import AdminDashboard from "./admin/Dashboard";
import AdminMaterials from "./admin/Materials";
import MentorLogin from "./mentor/login";
import MentorRoutes from "./utils/MentorRoutes";
import MentorDashboard from "./mentor/Dashboard";
import MentorAddQuestion from "./mentor/AddQuestions";
import MentorShowQuestions from "./mentor/ShowQuestions";
import AssignPractice from "./mentor/AssignPractice";
import MyAssignments from "./mentor/MyAssignments";
import Practice from "./modules/practice";
import StudentProfile from "./admin/StudentProfile";
import DoodleAdmin from "./admin/Doodle";
import StudNotifyAdmin from "./admin/StudNotify";
import StudNotifyToast from "./common/StudNotifyToast";
import QuestionAnalytics from "./admin/QuestionAnalytics";
import Attendance from "./admin/Attendance";
import StudentCount from "./admin/StudentCount";
import AdminDoubts from "./admin/Doubts";
import MentorSubjects from "./admin/MentorSubjects";

function App() {
  return (
    <>
      <ToastContainer autoClose={1500} stacked />
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Home />
              </ProtectedRoute>
            }
          />
          {/* <Route path="/home2" element={<HomeTwo />} />
          <Route path="/home3" element={<Home />} />*/}
          {/* <Route path="/schedule" element={<Schedule />} /> */}
          {/* <Route path="/mentor_course" element={<StudentCourse />} />  */}
          {/* <Route
            path="/students"
            element={
              <ProtectedRoute>
                <Students />
              </ProtectedRoute>
            }
          /> */}
          <Route
            path="/exams"
            element={
              <ProtectedRoute>
                <AccessGuard feature="exams">
                  <Exam />
                </AccessGuard>
              </ProtectedRoute>
            }
          />
          <Route
            path="/exam-result"
            element={
              <ProtectedRoute>
                <ExamResult />
              </ProtectedRoute>
            }
          />
          <Route
            path="/test"
            element={
              <ProtectedRoute>
                <GiveExam />
              </ProtectedRoute>
            }
          />
          <Route path="/testTopicListing" element={<TestTopicListing />} />
          <Route
            path="/syllabus"
            element={
              <ProtectedRoute>
                <AccessGuard feature="syllabus">
                  <Syllabus />
                </AccessGuard>
              </ProtectedRoute>
            }
          />
          <Route
            path="/weightage"
            element={
              <ProtectedRoute>
                <AccessGuard feature="weightage">
                  <Weightage />
                </AccessGuard>
              </ProtectedRoute>
            }
          />
          <Route
            path="/analytics"
            element={
              <ProtectedRoute>
                <AccessGuard feature="analytics">
                  <Analytics />
                </AccessGuard>
              </ProtectedRoute>
            }
          />
          <Route
            path="/accuracyMatrix"
            element={
              <ProtectedRoute>
                <AccessGuard feature="accuracy_matrix">
                  <MasteryMatrix />
                </AccessGuard>
              </ProtectedRoute>
            }
          />
          <Route
            path="/doubts"
            element={
              <ProtectedRoute>
                <AccessGuard feature="doubts">
                  <Doubts />
                </AccessGuard>
              </ProtectedRoute>
            }
          />
          <Route
            path="/solutions"
            element={
              <ProtectedRoute>
                <AccessGuard feature="solutions">
                  <Solutions />
                </AccessGuard>
              </ProtectedRoute>
            }
          />
          {/* <Route path="/mentors" element={<Mentor />} />
          <Route path="/resources" element={<Resources />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/events" element={<Events />} />
          <Route path="/library" element={<Library />} />*/}
          {/* <Route
            path="/pricing"
            element={
              <ProtectedRoute>
                <Pricing />
              </ProtectedRoute>
            }
          /> */}
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/quizdetail"
            element={
              <ProtectedRoute>
                <StudentQuizDetails />
              </ProtectedRoute>
            }
          />
          {/* Protect signin and signup routes */}
          <Route
            path="/signin"
            element={
              <PrivateRoute>
                <SignIn />
              </PrivateRoute>
            }
          />
          {/* <Route
            path="/signup"
            element={
              <PrivateRoute>
                <Signup />
              </PrivateRoute>`
            }
          /> */}
          <Route
            path="/forget_password"
            element={
              <PrivateRoute>
                <ForgetPassword />
              </PrivateRoute>
            }
          />
          <Route
            path="/reset_password"
            element={
              <PrivateRoute>
                <ResetPassword />
              </PrivateRoute>
            }
          />
          {/* <Route
            path="/two_step_verification"
            element={<TwoStepVerification />}
          /> */}
          {/* <Route path="/live_class" element={<LiveClass />} /> */}
          {/* Admin Routes */}
          <Route
            path="/admin/login"
            element={
              <PrivateRoute>
                <AdminLogin />
              </PrivateRoute>
            }
          />{" "}
          <Route
            path="/mentor/login"
            element={
              <PrivateRoute>
                <MentorLogin />
              </PrivateRoute>
            }
          />
          {/* ── Mentor Routes ── */}
          <Route
            path="/mentor/dashboard"
            element={
              <MentorRoutes>
                <MentorDashboard />
              </MentorRoutes>
            }
          />
          <Route
            path="/mentor/addQuestion"
            element={
              <MentorRoutes>
                <MentorAddQuestion />
              </MentorRoutes>
            }
          />
          <Route
            path="/mentor/showQuestions"
            element={
              <MentorRoutes>
                <MentorShowQuestions />
              </MentorRoutes>
            }
          />
          <Route
            path="/mentor/assignPractice"
            element={
              <MentorRoutes>
                <AssignPractice
                  Sidebar={require("./common/MentorSidebar").default}
                  basePath="/mentor"
                  headerText="Assign Practice"
                />
              </MentorRoutes>
            }
          />
          <Route
            path="/mentor/myAssignments"
            element={
              <MentorRoutes>
                <MyAssignments
                  Sidebar={require("./common/MentorSidebar").default}
                />
              </MentorRoutes>
            }
          />
          {/* ── Admin Practice Routes ── */}
          <Route
            path="/admin/assignPractice"
            element={
              <AdminRoutes>
                <AssignPractice
                  Sidebar={require("./common/AdminSidebar").default}
                  basePath="/admin"
                  headerText="Assign Practice (Admin)"
                />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/practiceAssignments"
            element={
              <AdminRoutes>
                <MyAssignments
                  Sidebar={require("./common/AdminSidebar").default}
                />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/batchAccess"
            element={
              <AdminRoutes>
                <BatchAccess />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/studentAnswers"
            element={
              <AdminRoutes>
                <StudentAnswers />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/doubts"
            element={
              <AdminRoutes>
                <AdminDoubts />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/mentorSubjects"
            element={
              <AdminRoutes>
                <MentorSubjects />
              </AdminRoutes>
            }
          />
          {/* ── Student Practice Route ── */}
          <Route
            path="/practice"
            element={
              <ProtectedRoute>
                <AccessGuard feature="practice">
                  <Practice />
                </AccessGuard>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/dashboard"
            element={
              <AdminRoutes>
                <AdminDashboard />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/materials"
            element={
              <AdminRoutes>
                <AdminMaterials />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/addQuestion"
            element={
              <AdminRoutes>
                <AddQuestion />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/showQuestions"
            element={
              <AdminRoutes>
                <ShowQuestions />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/createTest"
            element={
              <AdminRoutes>
                <CreateTest />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/showTests"
            element={
              <AdminRoutes>
                <ShowTests />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/quizResults"
            element={
              <AdminRoutes>
                <QuizResultsTab />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/addQuizQuestions"
            element={
              <AdminRoutes>
                <AddQuizQuestions />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/viewQuizQuestions"
            element={
              <AdminRoutes>
                <ViewQuizQuestions />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/questionVerification"
            element={
              <AdminRoutes>
                <QuestionVerification />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/assignBatch"
            element={
              <AdminRoutes>
                <AssignBatchToTest />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/addSession"
            element={
              <AdminRoutes>
                <AddSession />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/showSession"
            element={
              <AdminRoutes>
                <ShowSession />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/assignSessionToBatch"
            element={
              <AdminRoutes>
                <AssignSessionToBatch />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/viewGivenExamData"
            element={
              <AdminRoutes>
                <ViewGivenExamData />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/viewStudentWiseGivenExamData"
            element={
              <AdminRoutes>
                <StudentWiseExamData />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/test/:slug"
            element={
              <AdminRoutes>
                <ShowTests />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/studNotify"
            element={
              <AdminRoutes>
                <StudNotifyAdmin />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/doodle"
            element={
              <AdminRoutes>
                <DoodleAdmin />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/questionAnalytics"
            element={
              <AdminRoutes>
                <QuestionAnalytics />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/attendance"
            element={
              <AdminRoutes>
                <Attendance />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/studentCount"
            element={
              <AdminRoutes>
                <StudentCount />
              </AdminRoutes>
            }
          />
          <Route
            path="/admin/studentProfile/:student_id"
            element={
              <AdminRoutes>
                <StudentProfile />
              </AdminRoutes>
            }
          />
          <Route path="/college-prediction" element={<CollgePredication />} />
          <Route path="*" element={<Error404 />} />
        </Routes>
        <StudNotifyToast />
      </BrowserRouter>
    </>
  );
}

export default App;
